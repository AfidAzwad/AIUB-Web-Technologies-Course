<h1>User Date</h1>
<?php

  echo $_POST['f_name'] . "<br>";
  echo $_POST['pwd'] . "<br>";
  echo $_POST['u_email'] . "<br>";
  echo $_POST['u_address'] . "<br>";
  echo $_POST['u_age'] . "<br>";
  echo $_POST['u_dob'] . "<br>";
  echo $_POST['gender'] . "<br>";
  echo $_POST['blood_group'] . "<br>";
  echo $_POST['ssc'] . "<br>";
  echo $_POST['hsc'] . "<br>";
  echo $_POST['bsc'] . "<br>";

?>
