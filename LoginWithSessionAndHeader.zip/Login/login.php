<?php
  session_start();
  $reqUname = $reqPwd = "";
  $reqUnameErr = $reqPwdErr = "";

  $userNameDB = "uname1";
  $passDB = "1234";

  if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST['u_name'])){
      $reqUnameErr = "Username cannot be empty!";
    }
    else{
      $reqUname = $_POST['u_name'];
    }

    if(empty($_POST['pwd'])){
      $reqPwdErr = "Password cannot be empty!";
    }
    else{
      $reqPwd = $_POST['pwd'];
    }

    if($reqUname != $userNameDB){
      $reqUnameErr = "Username incorrect!";
    }
    else{
      if($reqPwd != $passDB){
        $reqPwdErr = "Password wrong!";
      }
      else{
        $_SESSION['userName'] = $reqUname;
        header("Location: welcome.php");
      }
    }


  }

?>


<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
  </head>
  <body>
    <form class="" action="login.php" method="post">
      <label for="">Username: </label>
      <input type="text" name="u_name" value="<?php echo $reqUname; ?>" required>
      <span style="color:red;"><?php echo $reqUnameErr; ?></span> <br>
      <label for="">Password: </label>
      <input type="password" name="pwd" value="" required>
      <span style="color:red;"><?php echo $reqPwdErr; ?></span> <br>
      <input type="submit" name="lgin_btn" value="Login">
    </form>
  </body>
</html>
